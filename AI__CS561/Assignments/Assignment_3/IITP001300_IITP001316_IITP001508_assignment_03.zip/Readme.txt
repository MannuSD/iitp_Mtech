This directory contains the solutin to Assignment 3 of CS561 - Executive-Assignment-3 Lab

Group:
1. Sukhvinder Singh : 
     Addmission Number: IITP001300
     email ID: sukhvinder.malik13@gmail.com
2. Manjit Singh Duhan : 
     Addmission Number: IITP001316
     email id: duhan.manjit@gmail.com
3. Atul Singh : 
     Addmission Number: IITP001508
     email id: atulsingh.xcvi@gmail.com

Note: This assignment is solved using jupyter Notebook.

Files:
1. A_star.ipynb : This file contains the code to solve the 8 puzzle using A* search algorithm.
2. assignment_3_answer.docx: This file the answer to the questions asked.