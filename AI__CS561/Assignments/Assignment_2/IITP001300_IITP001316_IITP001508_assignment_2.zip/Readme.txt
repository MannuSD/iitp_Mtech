This directory contains the solutin to Assignment 2 of CS561 - Executive-Assignment-2 Lab

Group:
1. Sukhvinder Singh : 
     Addmission Number: IITP001300
     email ID: sukhvinder.malik13@gmail.com
2. Manjit Singh Duhan : 
     Addmission Number: IITP001316
     email id: duhan.manjit@gmail.com
3. Atul Singh : 
     Addmission Number: IITP001508
     email id: atulsingh.xcvi@gmail.com

Note: This assignment is solved using jupyter Notebook but as per requirement saved the code in .py format.

Files:
1. assignment_2.py : This file contains the code to solve the 8 puzzle.
2. assignment_2_Class_Diagram.html :This document contains class diagram of the code.
3. assignment_2.docx: This file contains the explanation of the code as well as comparasion of all the 4 algorithms i.e. BFS, DFS, UCS, IDS.