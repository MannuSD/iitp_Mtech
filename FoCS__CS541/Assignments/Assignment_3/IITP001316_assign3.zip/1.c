/******************************************************************************
* Executive M.Tech (AI & DSE)
* Subject: CS559 - Computer Systems Lab
* Name: Manjit Singh Duhan
* Addmission No: IITP001316
* email id: duhan.manjit@gmail.com
*
* *******************************************************************************/

#include <stdio.h>
#include <stdlib.h>

struct bcd_sum{
    int number_of_bits;
    int decimal_value;
    int bcd_value;
    int error;
};

static void print_bcd_in_binary(int bcd_value);
static int dec2bcd(int value);
static int get_num_of_digit(int bcd);
static int get_user_input(int *number_of_bits, int* value);


int main()
{
    int count;
    struct bcd_sum *bcd = NULL;

    printf("\nNumber of test cases: ");
    scanf("%d", &count);
    
    bcd = (struct bcd_sum *)(calloc(count, sizeof(struct bcd_sum)));
    if(bcd == NULL)
    {
        printf("ERROR: Not able to allocate memory. Exitting...");
        return -1;
    }
    
    for(int i = 0; i < count; i++)
    {
        int number_of_bits = 0;
        int value = 0;
        
        if (get_user_input(&number_of_bits, &value) != 0)
        {
            return -1;
        }
        
        bcd[i].number_of_bits = number_of_bits;
        bcd[i].decimal_value = value;
        bcd[i].bcd_value = dec2bcd(value);
        
        number_of_bits = get_num_of_digit(bcd[i].bcd_value);
        if((number_of_bits*4) > bcd[i].number_of_bits)
        {
            bcd[i].error = -1;
        }
    }
    
    for(int i = 0; i < count; i++)
    {
        printf("\nBCD equivalent: ");

        if (bcd[i].error == 0)
        {
            print_bcd_in_binary(bcd[i].bcd_value);
        }
        else
        {
            printf("cannot be represented");
        }
    }

    return 0;
}

/******************************************************************************
* \brief  print the BCD value in the binary string format
*
* \param[in] bcd_value: the value in BCD format
*
* \return : None
* *****************************************************************************/
static void print_bcd_in_binary(int bcd_value)
{
    int reverse = 0;

    while(bcd_value)
    {
        reverse = reverse << 4;
        reverse |= (bcd_value&0xF);
        
        bcd_value = bcd_value >> 4;
    }
    
    while(1)
    {
        int temp = reverse&0xF;
        for(int i = 3; i >=0; i--)
        {
            printf("%d", (temp & (1 << i))? 1 : 0);
        }
        
        reverse = reverse >> 4;;
        
        if(reverse == 0)
        {
            break;
        }
        
        printf(" ");
    }
}

/******************************************************************************
* \brief  convert the decimal format value in the BCD format
*
* \param[in] value: decimal format value
*
* \return : BCD format
******************************************************************************/
static int dec2bcd(int value)
{
    int retVal = 0;
    int i = 0;
    while(value)
    {
        int temp = (value%10);
        retVal = retVal | (temp << 4*i);
        value /=10;
        i++;
    }
    
    return retVal;
}

/******************************************************************************
* \brief  get the number of digits in the give BCD number
*
* \param[in] bcd: BCD format number
*
* \return : Number of digit in the BCD number
******************************************************************************/
static int get_num_of_digit(int bcd)
{
    int retVal = 0;
    
    if(bcd == 0)
    {
        return 1;
    }
    
    while(bcd)
    {
        retVal++;
        bcd = bcd >> 4;
    }
    
    return retVal;
}

/******************************************************************************
* \brief  Take the input from user
*
* \param[out] number of bits
* \param[out] decimal format number
*
* \return : 0 if input by user is valid otherwise -1
******************************************************************************/
int get_user_input(int *number_of_bits, int* value)
{
    int temp = 0;
    printf("\nBits available? : ");
    scanf("%d", &temp);
    
    if(temp <= 0 || temp%4 != 0)
    {
        printf("\nWrong input entered by user");
        return -1;
    }
    
    *number_of_bits = temp;
    
    printf("Decimal Number: ");
    scanf("%d", &temp);
    
    if(temp < 0)
    {
        printf("\nWrong input entered by user");
        return -1;
    }
    
    *value = temp;
    
    return 0;
}
