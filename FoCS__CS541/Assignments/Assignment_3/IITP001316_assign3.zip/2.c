/******************************************************************************
* Executive M.Tech (AI & DSE)
* Subject: CS559 - Computer Systems Lab
* Name: Manjit Singh Duhan
* Addmission No: IITP001316
* email id: duhan.manjit@gmail.com
* Assignement 3
*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

/*This structure will hold the respective values.*/
struct bcd_sum{
    int first_num;
    int second_num;
    int sum;
};

static void print_bcd_in_binary(int bcd_value);
static int dec2bcd(int value);
static int bcd2dec(int bcd);
static int do_binary_addition(char a, char b);
static int get_bcd_sum(int a, int b);
static int get_user_input(int *val1, int* val2);


int main()
{
    int count;
    struct bcd_sum *bcd = NULL;

    printf("\nNumber of test cases: ");
    scanf("%d", &count);
    if(count <= 0) {
       printf("ERROR: Number of test case can not be 0 or negative. Exitting...");
       return -1; 
    }
    
    
    bcd = (struct bcd_sum *)(calloc(count, sizeof(struct bcd_sum)));
    if(bcd == NULL) {
        printf("ERROR: Not able to allocate memory. Exitting...");
        return -1;
    }
    
    for(int i = 0; i < count; i++) {
        int value1 = 0;
        int value2 = 0;
        
        if (get_user_input(&value1, &value2) != 0) {
            return -1;
        }

        bcd[i].first_num = value1;
        value1 = dec2bcd(value1);
        
        bcd[i].second_num = value2;
        value2 = dec2bcd(value2);

        bcd[i].sum = get_bcd_sum(value1, value2);
    }
    
    for(int i = 0; i < count; i++) {
        int value1 = 0;
        int value2 = 0;

        printf("\n %d (", bcd[i].first_num);
        value1 = dec2bcd(bcd[i].first_num); 
        print_bcd_in_binary(value1);
        printf(")");
        
        printf(" + ");
        
        printf("%d (", bcd[i].second_num);
        value2 = dec2bcd(bcd[i].second_num);
        print_bcd_in_binary(value2);
        printf(")");
        
        printf(" = %d (", bcd2dec(bcd[i].sum)); //Just for printing purpose doing bcd2dec comversion
        print_bcd_in_binary(bcd[i].sum);
        printf(")");
    }

    return 0;
}

/******************************************************************************
* \brief  print the BCD value in the binary string format
*
* \param[in] bcd_value: the value in BCD format
*
* \return : None
* *****************************************************************************/
static void print_bcd_in_binary(int bcd_value)
{
    int reverse = 0;

    /*For rase of printing, first reverse the digits i.e 123 will become 321 */
    while(bcd_value) {
        reverse = reverse << 4;
        reverse |= (bcd_value&0xF);
        
        bcd_value = bcd_value >> 4;
    }
    
    while(1) {
        int temp = reverse&0xF; //Take the LSB side nibble
        
        for(int i = 3; i >=0; i--) {
            printf("%d", (temp & (1 << i))? 1 : 0);
        }
        
        reverse = reverse >> 4;;
        
        if(reverse == 0) {
            break;
        }
        
        printf(" "); //print a blank space after every 4 binary values
    }
}

/******************************************************************************
* \brief  convert the decimal format value in the BCD format
*
* \param[in] value: decimal format value
*
* \return : BCD format
******************************************************************************/
static int dec2bcd(int value)
{
    int retVal = 0;
    int i = 0;
    while(value) {
        int temp = (value%10);
        retVal = retVal | (temp << 4*i);
        value /=10;
        i++;
    }
    
    return retVal;
}

/******************************************************************************
* \brief  convert the BCD format value in the decimal format
*
* \param[in] bcd: BCD format value
*
* \return : decimal format value
******************************************************************************/
static int bcd2dec(int bcd)
{
    int reverse_decimal_val = 0;
    int decimal_val = 0;

    while(bcd) {
        reverse_decimal_val = (reverse_decimal_val*10) + (bcd&0xF);
        bcd = bcd >> 4;
    }
    
    while(reverse_decimal_val) {
        decimal_val = decimal_val*10 + reverse_decimal_val%10;
        reverse_decimal_val /= 10;
    }
    
    return decimal_val;
}

/******************************************************************************
* \brief  Do the sum operation on the binary values
*
* \param[in] a: first BCD format nibble
* \param[in] b: second BCD format nibble
*
* \return : sum of a and b
******************************************************************************/
static int do_binary_addition(char a, char b)
{
    char carry = 0;
    
    while(b) {
       //shift it left and thake the carry
        carry = (a & b) << 1;

        //do the addition operation
        a ^= b;
        b = carry;
    }
    
    return a;
}

/******************************************************************************
* \brief  Do the sum operation on the BCD values
*
* \param[in] a: first BCD format value
* \param[in] b: second BCD format vale
*
* \return : sum of a and b
******************************************************************************/
static int get_bcd_sum(int a, int b)
{
    int sum = 0;
    int carry = 0;
    int i = 0;
    
    while ( a || b) {
        int temp = do_binary_addition(a&0xF, b&0xF);
        
        /*If we have carry from last operation then add it*/
        temp += carry;
        if(temp > 9) {
            /*If there result is > 9 then add 6 to it*/
            temp = do_binary_addition(temp&0xF, 6);
            temp &= 0xF;
            carry = 1;
        }
        else {
            carry = 0;
        }

        sum = sum | (temp << (4*i));

        i++;
        a = a >> 4;
        b = b >> 4;
    }
    
    /*It is possible the the sum of 1 digit BCD vales could be 2 digit BC value.
     So, handling the carry here*/
    sum = sum | (carry << (4*i));
    
    return sum;
}

/******************************************************************************
* \brief  Take the input from user
*
* \param[out] first number
* \param[out] second number
*
* \return : 0 if input by user is valid otherwise -1
******************************************************************************/
static int get_user_input(int *val1, int* val2)
{
    int temp = 0;
    printf("\nFirst Number : ");
    scanf("%d", &temp);
    
    if(temp < 0) {
        printf("Wrong input entered by user. Exitting...");
        return -1;
    }
    
    *val1 = temp;
    
    printf("Second Number: ");
    scanf("%d", &temp);
    
    if(temp < 0) {
        printf("Wrong input entered by user. Exitting...");
        return -1;
    }
    
    *val2 = temp;
    
    return 0;
}

